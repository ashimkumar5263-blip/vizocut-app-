VizoCut V29 - Export Duration Fix
Use 720p first. Exported format is WebM because HTML/WebView MediaRecorder cannot reliably create MP4 on Android.
